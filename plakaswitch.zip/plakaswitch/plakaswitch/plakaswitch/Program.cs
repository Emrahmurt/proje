﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                Console.WriteLine("Araç kapasitesi kaçtır?");
                int servisKapasitesi = Convert.ToInt32(Console.ReadLine());

                List<string> öğrenciListe = new List<string>();
                int öğrencisayi = 0;

                Console.WriteLine("Geziye katılacak öğrencilerin isimlerini giriniz:");

                while (true)
                {
                    string öğrenciAdı = Console.ReadLine();

                    if (string.IsNullOrEmpty(öğrenciAdı)) // Eğer giriş boşsa döngüden çık
                        break;

                    öğrenciListe.Add(öğrenciAdı);
                    öğrencisayi++;

                    int kalanYer = servisKapasitesi - (öğrencisayi % servisKapasitesi);

                    if (öğrencisayi <= servisKapasitesi)
                    {
                        Console.WriteLine("Yer var: Öğrenciler servise sığar.");
                    }
                    else
                    {
                        Console.WriteLine("Yer yok: Öğrenciler servise sığmaz.");
                    }

                    Console.WriteLine("Toplam öğrenci sayısı: " + öğrencisayi);
                    Console.WriteLine("Kalan yer sayısı: " + kalanYer);

                    Console.WriteLine("Başka bir öğrenci eklemek ister misiniz? (Evet/Hayır)");
                    string devamEt = Console.ReadLine().ToLower();
                    if (devamEt != "evet")
                        break;
                }

                Console.WriteLine("\nÖğrenci Listesi:");
                foreach (var öğrenci in öğrenciListe)
                {
                    Console.WriteLine(öğrenci);
                }

            }
        }
    }
}